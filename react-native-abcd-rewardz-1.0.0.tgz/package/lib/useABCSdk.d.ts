/**
 * useABCSdk.ts
 *
 * Unified React hook for the Loylty Rewardz (ABCD) SDK.
 *
 * Both Android and iOS now emit the same three DeviceEvents
 * (BackToHomeCallback, UserLogoutCallback, SessionCallback) so this hook
 * subscribes to those events once and requires zero platform checks.
 *
 * Usage
 * -----
 * ```tsx
 * import { useABCSdk } from 'react-native-abcd-rewardz';
 *
 * function RewardsScreen() {
 *   const { launchSdk, clearSession } = useABCSdk({
 *     onHome:    () => navigation.goBack(),
 *     onLogout:  () => dispatch(logoutAction()),
 *     onTimeout: () => Alert.alert('Session expired'),
 *   });
 *
 *   return <Button title="Open Rewards" onPress={() => launchSdk(userToken)} />;
 * }
 * ```
 */
import { UseABCSdkOptions, UseABCSdkReturn } from './types';
export declare function useABCSdk(options?: UseABCSdkOptions): UseABCSdkReturn;
